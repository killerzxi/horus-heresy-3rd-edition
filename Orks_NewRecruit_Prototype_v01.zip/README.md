# Orks in Horus Heresy 3.0 — New Recruit PROTOTYPE (v0.1)

SOURCE: "Xenos Forces of the Age of Darkness: Orks", unofficial fan supplement by Always Strikes First, updated October 2025. Not endorsed by Games Workshop or the original fan authors.

## What this package does
- Includes the 52 unit entries from PDF pages 7–42, using the fan PDF's **base points costs**, unit sizes and costs for additional models.
- Uses New Recruit's existing community **Horus Heresy 3rd Edition** system ID, Battlefield Role IDs, profile type IDs and point-cost ID.
- Includes initial selections for several conspicuous upgrades: Warboss equipment, Trukks, Stompa arms/deflektor, Big Mek, Bigboss, Kill Tank variants and common Nob promotions.
- Includes clan selections so a player can record a chosen clan. Clan rules themselves are not automated.
- Original source PDF is required for unit special rules and precise weapon/option restrictions.

## STATUS — IMPORTANT
This is a **draft catalogue**, NOT a fully playtested/installed New Recruit faction.
It is **not a guaranteed drop-in import** to the official game already installed in your NR account.
There are known omissions: full weapon profiles, replacement model stat application, many wargear upgrades, conditional options, exact detachment availability and clan bonuses. Do NOT regard a 'valid list' indication as a guarantee of legal Horus Heresy 3.0 composition.

## Suggested testing route
1. Fork https://github.com/BSData/horus-heresy-3rd-edition in GitHub (don't modify the community project's public repository directly).
2. At the ROOT of your fork, upload `Orks.json` alongside `Imperialis Militia.json`, `Weapons.json`, `Special Rules.json` etc.
3. In New Recruit, use **Add or Remove Games** / **Add from GitHub**, and enter your fork URL (see https://github-wiki-see.page/m/BSData/catalogue-development/wiki/Hosting-repositories).
4. Open the newly added forked Horus Heresy 3rd Edition game rather than the normal public install.
5. Look for the `Orks (Unofficial HH3, Prototype)` faction. If the base data or force chart does not expose it, we will adjust the root entries / force selectors using New Recruit Editor; it has not yet been validated inside the app.
6. Check a 10-model Slugga Mob = 60 pts; 20-model Mob = 110 pts; Stompa = 770 pts before upgrades.

## Next implementation steps
- Hook the Ork-specific Apex/Auxiliary detachments (Deffwing, Dread Mob, Boss's Bodyguard, Green Tide, Kult of Speed) into the forked GST. This requires editing the game-system file; a faction catalogue cannot achieve everything alone.
- Implement all per-model weapon swaps including per-five caps and standard wargear costs.
- Implement clan Traits, advanced reactions, new weapons and special rules in correct library profiles.
- Add fully automatic character/variant profile swapping and force limits, then test in New Recruit.

`unit_audit.csv` is a human-checkable extraction of prices and initial squad sizes, included for review.
